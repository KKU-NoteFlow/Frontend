import React, { useState, useEffect, useCallback } from 'react'
import '../css/Sidebar.css'

export default function Sidebar({ onFilterChange, onNoteSelect }) {
  const [flatFolders, setFlatFolders] = useState([])
  const [treeFolders, setTreeFolders] = useState([])
  const [openMap, setOpenMap] = useState({})
  const [folderNoteMap, setFolderNoteMap] = useState({})
  const [contextMenu, setContextMenu] = useState({ visible: false, x: 0, y: 0, folderId: null })

  // 폴더 불러오기
  const loadFolders = useCallback(async () => {
    const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/v1/folders`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` }
    })
    if (!res.ok) return
    const data = await res.json()
    setFlatFolders(data)
  }, [])

  // 노트 불러오기
  const loadNotes = useCallback(async () => {
    const res = await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/v1/notes`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` }
    })
    if (!res.ok) return
    const data = await res.json()
    const map = {}
    data.forEach(note => {
      if (!map[note.folder_id]) map[note.folder_id] = []
      map[note.folder_id].push(note)
    })
    setFolderNoteMap(map)
  }, [])

  // flat → 트리 구조 변환
  useEffect(() => {
    const map = {}
    flatFolders.forEach(f => { map[f.id] = { ...f, children: [] } })
    const roots = []
    flatFolders.forEach(f => {
      if (f.parent_id == null) {
        roots.push(map[f.id])
      } else if (map[f.parent_id]) {
        map[f.parent_id].children.push(map[f.id])
      }
    })
    setTreeFolders(roots)
  }, [flatFolders])

  // 첫 마운트 시 폴더 + 노트 로드
  useEffect(() => {
    loadFolders()
    loadNotes()
  }, [loadFolders, loadNotes])

  // 폴더 펼치기/접기
  const toggle = id =>
    setOpenMap(prev => ({ ...prev, [id]: !prev[id] }))

  // 노트 드래그 시 폴더로 이동
  const handleDrop = async (e, folderId) => {
    const noteId = e.dataTransfer.getData('noteId')
    await fetch(
      `${import.meta.env.VITE_API_BASE_URL}/api/v1/notes/${noteId}`,
      {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('access_token')}`
        },
        body: JSON.stringify({ folder_id: folderId })
      }
    )
    onFilterChange('all')
    e.preventDefault()
  }

  // 새 폴더 생성
  const handleNewFolder = async parentId => {
    const name = prompt('새 폴더 이름을 입력하세요')
    if (!name) return
    await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/v1/folders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('access_token')}`
      },
      body: JSON.stringify({ name, parent_id: parentId })
    })
    loadFolders()
  }

  const handleNewNote = async folderId => {
    const title = prompt('노트 제목을 입력하세요')
    if (!title) return
    await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/v1/notes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('access_token')}`
      },
      body: JSON.stringify({
        title,
        content: '',
        folder_id: folderId
      })
    })
    loadNotes()
  }
  const handleRenameFolder = async folderId => {
    const newName = prompt('새 이름을 입력하세요')
    if (!newName) return
    await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/v1/folders/${folderId}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('access_token')}`
      },
      body: JSON.stringify({ name: newName })
    })
    loadFolders()
  }

  const handleDeleteFolder = async folderId => {
    if (!confirm('정말 삭제하시겠습니까?')) return
    await fetch(`${import.meta.env.VITE_API_BASE_URL}/api/v1/folders/${folderId}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${localStorage.getItem('access_token')}`
      }
    })
    loadFolders()
  }

  // 폴더 + 노트 트리 렌더링
  const renderTree = list =>
    list.map(node => (
      <li key={node.id}>
        <div
          className="folder-label"
          onClick={() => toggle(node.id)}
          onDrop={e => handleDrop(e, node.id)}
          onDragOver={e => e.preventDefault()}
          onContextMenu={e => {
            e.preventDefault()
            setContextMenu({ visible: true, x: e.clientX, y: e.clientY, folderId: node.id })
          }}
        >
          <span>
            {openMap[node.id] ? '▼' : '▶'} {node.name}
          </span>
          <button
            className="btn-new-child"
            onClick={e => {
              e.stopPropagation()
              handleNewFolder(node.id)
            }}
          >＋</button>
        </div>

        {/* 노트 목록 */}
        {openMap[node.id] && folderNoteMap[node.id] && (
          <ul className="folder-children">
            {folderNoteMap[node.id].map(note => (
              <li
                key={note.id}
                className="note-item"
                onClick={() => onNoteSelect(note)}
                draggable
                onDragStart={e => e.dataTransfer.setData('noteId', note.id)}
              >
                📄 {note.title || '(제목 없음)'}
              </li>
            ))}
          </ul>
        )}

        {/* 하위 폴더 */}
        {openMap[node.id] && node.children.length > 0 && (
          <ul className="folder-children">
            {renderTree(node.children)}
          </ul>
        )}
      </li>
    ))

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <img src="/logo.png" alt="NoteFlow Logo" className="logo-icon" />
        <span className="logo-text">NoteFlow</span>
      </div>

      <div className="sidebar-controls">
        <button onClick={() => onFilterChange('recent')}>최근 노트</button>
        <button onClick={() => onFilterChange('all')}>내 폴더</button>
        <button onClick={() => onFilterChange('favorites')}>즐겨찾기</button>
        <button className="btn-new-root" onClick={() => handleNewFolder(null)}>+ 새 폴더</button>
      </div>

      <ul className="folder-list">
        {renderTree(treeFolders)}
      </ul>

      {contextMenu.visible && (
        <div
          className="context-menu"
          style={{ top: contextMenu.y, left: contextMenu.x, position: 'fixed', zIndex: 1000 }}
          onClick={() => setContextMenu({ ...contextMenu, visible: false })}
        >
          <div onClick={() => handleNewNote(contextMenu.folderId)}>➕ 새 노트</div>
          <div onClick={() => handleRenameFolder(contextMenu.folderId)}>✏️ 이름 변경</div>
          <div onClick={() => handleDeleteFolder(contextMenu.folderId)}>🗑️ 삭제</div>
        </div>
      )}
    </aside>
  )
}
